﻿function validateField(value, rules) {
    for (var i = 0; i < rules.length; i++) {
        var rule = rules[i];
        if (rule.type === "required" && (!value || value.trim() === "")) {
            return rule.message;
        }
        if (rule.type === "minLength" && value.length < rule.value) {
            return rule.message;
        }
        if (rule.type === "maxLength" && value.length > rule.value) {
            return rule.message;
        }
    }
    return null;
}

$(document).ready(function () {
    $('#submitBtn').click(function () {
        var firstName = $('#firstName').val();
        var lastName = $('#lastName').val();

        var validations = {
            firstName: [
                { type: "required", message: "First name is required" }
            ],
            lastName: [
                { type: "required", message: "Last name is required" },
                { type: "maxLength", value: 100, message: "Last name should not exceed 100 characters" }
            ]
        };

        var firstNameError = validateField(firstName, validations.firstName);
        var lastNameError = validateField(lastName, validations.lastName);

        if (firstNameError) {
            $('#firstNameError').text(firstNameError).show();
        } else {
            $('#firstNameError').hide();
        }

        if (lastNameError) {
            $('#lastNameError').text(lastNameError).show();
        } else {
            $('#lastNameError').hide();
        }

        if (!firstNameError && !lastNameError) {
            alert("Form is valid and ready to be submitted.");

            var UserDto = {
                FirstName: firstName,
                LastName: lastName
            }

            $.ajax({
                url: 'http://localhost:5149/api/Users/CreateUser',
                type: 'Post',
                contentType: 'application/json',
                data: JSON.stringify(UserDto),

                success: function (data) {

                    if (data !== null) {
                        alert("Saved Successfully");
                    }

                },
                error: function (data) {

                }
            })

        }
    });
});
