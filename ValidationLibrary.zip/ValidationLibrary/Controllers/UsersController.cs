﻿using Microsoft.AspNetCore.Mvc;
using ValidationLibrary.Validations;

namespace ValidationLibrary.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly ValidationService _validationService;

        public UsersController(ValidationService validationService)
        {
            _validationService = validationService;
        }

        [HttpPost]
        [Route("CreateUser")]
        public IActionResult CreateUser([FromBody] UserDto userDto)
        {
            var rules = new Dictionary<string, List<ValidationRule>>
        {
            { "FirstName", new List<ValidationRule> { new RequiredValidation("First name is required") } },
            { "LastName", new List<ValidationRule> {
                new RequiredValidation("Last name is required"),
                new MaxLengthValidation(100, "Last name should not exceed 100 characters")
            } }
        };

            var data = new Dictionary<string, string>
        {
            { "FirstName", userDto.FirstName },
            { "LastName", userDto.LastName }
        };

            var result = _validationService.Validate(data, rules);

            if (!result.IsValid)
            {
                return BadRequest(new
                {
                    isValid = result.IsValid,
                    errors = result.Errors
                });
            }

            // If validation passes, save user or perform other logic.
            return Ok(new { message = "User created successfully!" });
        }
    }

}
