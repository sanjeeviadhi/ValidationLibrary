﻿namespace ValidationLibrary
{
    public class UserDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
