﻿namespace ValidationLibrary.Validations
{
    public class MinLengthValidation : ValidationRule
    {
        private const int MinLength = 3; // set fixed value here

        public MinLengthValidation(string errorMessage) : base(errorMessage) { }

        public override bool IsValid(string value)
        {
            return !string.IsNullOrEmpty(value) && value.Length >= MinLength;
        }
    }
}
