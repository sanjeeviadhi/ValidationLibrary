﻿namespace ValidationLibrary.Validations
{
    public class ValidationResult
    {
        public bool IsValid { get; set; }
        public Dictionary<string, string> Errors { get; set; }

        public ValidationResult()
        {
            Errors = new Dictionary<string, string>();
            IsValid = true;
        }

        public void AddError(string fieldName, string message)
        {
            IsValid = false;
            if (!Errors.ContainsKey(fieldName))
            {
                Errors.Add(fieldName, message);
            }
        }
    }
}
