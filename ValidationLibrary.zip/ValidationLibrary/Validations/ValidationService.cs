﻿namespace ValidationLibrary.Validations
{
    public class ValidationService
    {
        public ValidationResult Validate(Dictionary<string, string> data, Dictionary<string, List<ValidationRule>> rules)
        {
            var validationResult = new ValidationResult();

            foreach (var field in rules)
            {
                string fieldName = field.Key;
                string fieldValue = data.ContainsKey(fieldName) ? data[fieldName] : string.Empty;

                foreach (var rule in field.Value)
                {
                    if (!rule.IsValid(fieldValue))
                    {
                        validationResult.AddError(fieldName, rule.ErrorMessage);
                    }
                }
            }

            return validationResult;
        }
    }

}
