﻿namespace ValidationLibrary.Validations
{
    public class MaxLengthValidation : ValidationRule
    {
        public int MaxLength { get; set; }

        public MaxLengthValidation(int maxLength, string errorMessage) : base(errorMessage)
        {
            MaxLength = maxLength;
        }

        public override bool IsValid(string value)
        {
            return value.Length <= MaxLength;
        }
    }
}
