﻿namespace ValidationLibrary.Validations
{
    public class RequiredValidation : ValidationRule
    {
        public RequiredValidation(string errorMessage) : base(errorMessage) { }

        public override bool IsValid(string value)
        {
            return !string.IsNullOrWhiteSpace(value);
        }
    }
}
