﻿namespace ValidationLibrary.Validations
{
    public abstract class ValidationRule
    {
        public string ErrorMessage { get; set; }

        public ValidationRule(string errorMessage)
        {
            ErrorMessage = errorMessage;
        }

        public abstract bool IsValid(string value);
    }
}
